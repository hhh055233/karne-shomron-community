# קרני שומרון קומיוניטי

מבנה הפרויקט מוכן ל-Cloudflare Workers + Assets + D1.

## מבנה
- `public/index.html` — ממשק האתר
- `src/index.js` — Cloudflare Worker
- `migrations/0001_init.sql` — טבלאות בסיס
- `migrations/0002_board_tasks.sql` — משימות בורד
- `wrangler.toml` — הגדרות Wrangler

## לפני Deploy
יש להחליף ב-`wrangler.toml` את:
- `REPLACE_WITH_D1_DATABASE_ID`
- `REPLACE_WITH_GITHUB_OWNER`
- `REPLACE_WITH_GITHUB_REPO`

אין למחוק את קבצי ה-migrations.
